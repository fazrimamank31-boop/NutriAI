import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini client with aistudio-build telemetry header
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

async function main() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // JSON body parser with increased limit for photo base64
  app.use(express.json({ limit: '20mb' }));

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY'),
    });
  });

  // Nutrition Analysis API endpoint
  app.post('/api/analyze-nutrition', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg', foodHint } = req.body;

      if (!imageBase64) {
        return res.status(400).json({ error: 'Foto makanan tidak ditemukan. Silakan unggah gambar makanan terlebih dahulu.' });
      }

      // Check if API key is present and valid
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        console.warn('GEMINI_API_KEY is not configured, providing intelligent educational sample response.');
        return res.json({
          foodName: foodHint || 'Nasi Kotak Ayam Panggang & Sayur Sop (Demo Sekolah)',
          servingSize: '1 porsi bekal sekolah (~320g)',
          calories: 520,
          carbohydrates: 68,
          protein: 28,
          fat: 14,
          fiber: 5,
          healthReview: 'Makanan ini memiliki komposisi gizi yang seimbang untuk siswa sekolah. Sumber karbohidrat dari nasi menyediakan energi belajar, daging ayam menyumbang protein untuk masa pertumbuhan dan regenerasi sel, serta sayur sop kaya akan serat alami dan vitamin penting.',
          nutritionistAdvice: 'Sangat cocok untuk bekal makan siang di sekolah! Untuk melengkapi gizi "Isi Piringku", tambahkan sebutir buah segar seperti pisang atau jeruk serta pastikan meminum air putih minimal 1-2 gelas setelah makan untuk menjaga konsentrasi belajar.',
          nutriScore: 'A (Sangat Seimbang)',
          schoolSuitability: 'Sangat Direkomendasikan untuk Makan Siang Sekolah',
          macroPercentages: {
            carbsPercent: 52,
            proteinPercent: 22,
            fatPercent: 26,
          },
          isDemoFallback: true,
        });
      }

      // Handle image payload: could be data URL, raw base64, or an image URL (from sample presets)
      let cleanBase64 = imageBase64;
      let detectedMime = mimeType || 'image/jpeg';

      if (imageBase64.startsWith('http://') || imageBase64.startsWith('https://')) {
        try {
          const imgRes = await fetch(imageBase64);
          if (imgRes.ok) {
            const arrayBuf = await imgRes.arrayBuffer();
            cleanBase64 = Buffer.from(arrayBuf).toString('base64');
            const fetchedMime = imgRes.headers.get('content-type');
            if (fetchedMime) detectedMime = fetchedMime;
          }
        } catch (fetchErr) {
          console.warn('Could not fetch remote image URL, proceeding with fallback parsing:', fetchErr);
        }
      } else if (imageBase64.includes(';base64,')) {
        const parts = imageBase64.split(';base64,');
        detectedMime = parts[0].replace('data:', '') || mimeType;
        cleanBase64 = parts[1];
      }

      const promptText = `Anda adalah seorang Ahli Gizi Edukatif untuk siswa sekolah (SD, SMP, SMA) di Indonesia.
Analisis foto makanan yang diunggah oleh siswa untuk tugas sekolah mata pelajaran IPA / Biologi / Prakarya / Pendidikan Jasmani & Kesehatan.

Tugas Anda:
1. Identifikasi nama makanan atau hidangan dengan akurat dalam Bahasa Indonesia.
2. Perkirakan ukuran porsi wajar siswa (contoh: 1 porsi sedang ~250 gram, 1 mangkok, 1 potong).
3. Hitung estimasi kandungan gizi berdasarkan standar AKG (Angka Kecukupan Gizi):
   - Total Kalori (kkal)
   - Karbohidrat (gram)
   - Protein (gram)
   - Lemak (gram)
   - Serat pangan / Fiber (gram)
4. Buat sebuah "Ulasan Kesehatan Singkat" (1-2 paragraf) yang menjelaskan manfaat kandungan makanan ini bagi tubuh dan energi pelajar.
5. Buat "Saran Edukatif dari Ahli Gizi" yang ramah, memotivasi, dan memberikan tips kebiasaan makan sehat bagi siswa (misal: pentingnya sarapan, minum air putih, porsi sayur, dsb).
6. Berikan Nilai Gizi / Nutri-Score (A: Sangat Sehat & Seimbang, B: Baik & Sehat, C: Cukup / Perlu Tambahan Sayur-Buah, D: Perlu Dibatasi karena tinggi gula/minyak).
${foodHint ? `Catatan tambahan dari siswa: "${foodHint}".` : ''}

Pastikan data berupa angka yang realistis dan ulasan yang edukatif dan positif.`;

      let parsedData;

      try {
        // Use modern Gemini Flash model
        const response = await ai.models.generateContent({
          model: 'gemini-flash-latest',
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: detectedMime,
                  data: cleanBase64,
                },
              },
              {
                text: promptText,
              },
            ],
          },
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                foodName: {
                  type: Type.STRING,
                  description: 'Nama makanan atau hidangan yang terdeteksi secara spesifik',
                },
                servingSize: {
                  type: Type.STRING,
                  description: 'Estimasi takaran porsi (contoh: 1 porsi sedang (~280g))',
                },
                calories: {
                  type: Type.NUMBER,
                  description: 'Estimasi total kalori dalam satuan kkal',
                },
                carbohydrates: {
                  type: Type.NUMBER,
                  description: 'Kandungan karbohidrat dalam satuan gram',
                },
                protein: {
                  type: Type.NUMBER,
                  description: 'Kandungan protein dalam satuan gram',
                },
                fat: {
                  type: Type.NUMBER,
                  description: 'Kandungan lemak dalam satuan gram',
                },
                fiber: {
                  type: Type.NUMBER,
                  description: 'Kandungan serat dalam satuan gram',
                },
                healthReview: {
                  type: Type.STRING,
                  description: 'Paragraf ulasan singkat mengenai kesehatan makanan tersebut',
                },
                nutritionistAdvice: {
                  type: Type.STRING,
                  description: 'Saran edukatif dari ahli gizi untuk anak sekolah',
                },
                nutriScore: {
                  type: Type.STRING,
                  description: 'Nilai gizi makanan (contoh: A - Sangat Sehat, B - Baik, dll)',
                },
                schoolSuitability: {
                  type: Type.STRING,
                  description: 'Kesesuaian makanan sebagai bekal atau makanan harian sekolah',
                },
              },
              required: [
                'foodName',
                'calories',
                'carbohydrates',
                'protein',
                'fat',
                'healthReview',
                'nutritionistAdvice',
              ],
            },
          },
        });

        const responseText = response.text;
        if (!responseText) {
          throw new Error('Model tidak memberikan respon teks');
        }
        parsedData = JSON.parse(responseText.trim());
      } catch (geminiErr: any) {
        console.warn('Gemini API call failed or requires billing, serving fallback estimation:', geminiErr.message);

        // Derive intelligent educational values based on food hint if available
        const title = foodHint || 'Menu Makanan & Bekal Sekolah';
        let cal = 485;
        let carb = 62;
        let prot = 22;
        let fat = 15;
        let fib = 4;

        if (title.toLowerCase().includes('goreng')) {
          cal = 530; carb = 66; prot = 17; fat = 22; fib = 2;
        } else if (title.toLowerCase().includes('buah') || title.toLowerCase().includes('salad')) {
          cal = 220; carb = 46; prot = 5; fat = 3; fib = 6;
        } else if (title.toLowerCase().includes('gado') || title.toLowerCase().includes('sayur')) {
          cal = 390; carb = 44; prot = 18; fat = 16; fib = 7;
        }

        parsedData = {
          foodName: title,
          servingSize: '1 porsi sedang (~280 gram)',
          calories: cal,
          carbohydrates: carb,
          protein: prot,
          fat: fat,
          fiber: fib,
          healthReview: `Makanan "${title}" ini kaya akan nutrisi makro yang penting untuk menunjang aktivitas belajar dan kegiatan fisik di sekolah. Kandungan karbohidratnya memberikan glukosa sebagai bahan bakar utama sel-sel otak saat menerima materi pelajaran, sementara proteinnya menopang pertumbuhan dan perbaikan jaringan tubuh siswa.`,
          nutritionistAdvice: 'Saran Ahli Gizi: Pastikan selalu mengimbangi porsi makanan pokok dengan porsi sayuran hijau dan buah-buahan segar sesuai pedoman "Isi Piringku". Minumlah air putih minimal 6-8 gelas sehari dan batasi makanan yang digoreng dengan minyak berulang.',
          nutriScore: 'A- (Sehat & Seimbang)',
          schoolSuitability: 'Sangat Cocok untuk Bekal & Makan Siang Sekolah',
          isDemoFallback: true,
        };
      }

      // Calculate macro percentage distribution
      const c = Number(parsedData.carbohydrates) || 0;
      const p = Number(parsedData.protein) || 0;
      const f = Number(parsedData.fat) || 0;
      const totalKcalFromMacros = (c * 4) + (p * 4) + (f * 9);
      const carbsPercent = totalKcalFromMacros > 0 ? Math.round(((c * 4) / totalKcalFromMacros) * 100) : 50;
      const proteinPercent = totalKcalFromMacros > 0 ? Math.round(((p * 4) / totalKcalFromMacros) * 100) : 25;
      const fatPercent = totalKcalFromMacros > 0 ? Math.max(0, 100 - carbsPercent - proteinPercent) : 25;

      return res.json({
        ...parsedData,
        macroPercentages: {
          carbsPercent,
          proteinPercent,
          fatPercent,
        },
      });
    } catch (error: any) {
      console.error('Error in /api/analyze-nutrition:', error);
      res.status(500).json({
        error: error.message || 'Gagal menganalisis foto makanan dengan AI. Silakan coba lagi.',
      });
    }
  });

  // Setup Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server Kalkulator Nutrisi AI Sekolah aktif di http://0.0.0.0:${PORT}`);
  });
}

main().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
