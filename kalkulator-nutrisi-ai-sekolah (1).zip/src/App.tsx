import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUploadArea } from './components/ImageUploadArea';
import { AnalyzeButton } from './components/AnalyzeButton';
import { NutritionResultCard } from './components/NutritionResultCard';
import { EducationalGuide } from './components/EducationalGuide';
import { StudentReportModal } from './components/StudentReportModal';
import { NutritionAnalysisResult, SampleFoodItem } from './types';
import { AlertCircle, History, Sparkles, BookCheck, RefreshCw } from 'lucide-react';

export default function App() {
  // State for image & form
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedMimeType, setSelectedMimeType] = useState<string>('image/jpeg');
  const [foodHint, setFoodHint] = useState<string>('');

  // Loading & Error states
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('AI sedang memindai foto makanan...');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Results & History
  const [result, setResult] = useState<NutritionAnalysisResult | null>(null);
  const [history, setHistory] = useState<NutritionAnalysisResult[]>(() => {
    try {
      const saved = localStorage.getItem('school_nutrition_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Student Project Metadata (for school assignment)
  const [studentName, setStudentName] = useState<string>(() => {
    return localStorage.getItem('school_student_name') || 'Muhammad Bintang Pratama';
  });
  const [studentClass, setStudentClass] = useState<string>(() => {
    return localStorage.getItem('school_student_class') || 'VIII-B';
  });
  const [studentNumber, setStudentNumber] = useState<string>(() => {
    return localStorage.getItem('school_student_number') || '18';
  });
  const [subjectName, setSubjectName] = useState<string>(() => {
    return localStorage.getItem('school_subject_name') || 'Ilmu Pengetahuan Alam (IPA) - Gizi Seimbang';
  });
  const [teacherName, setTeacherName] = useState<string>(() => {
    return localStorage.getItem('school_teacher_name') || 'Ibu Nurul Hidayah, S.Pd.';
  });

  const [showStudentModal, setShowStudentModal] = useState<boolean>(false);

  // Sync student info to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('school_student_name', studentName);
      localStorage.setItem('school_student_class', studentClass);
      localStorage.setItem('school_student_number', studentNumber);
      localStorage.setItem('school_subject_name', subjectName);
      localStorage.setItem('school_teacher_name', teacherName);
    } catch {
      // Ignore localStorage quotas in test environments
    }
  }, [studentName, studentClass, studentNumber, subjectName, teacherName]);

  // Sync history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('school_nutrition_history', JSON.stringify(history.slice(0, 8)));
    } catch {
      // Ignore
    }
  }, [history]);

  // Loading step simulation for engaging user experience
  useEffect(() => {
    if (!isLoading) return;

    const steps = [
      'Memindai visual makanan & mendeteksi bahan...',
      'Menghitung takaran porsi & estimasi kalori (kkal)...',
      'Menganalisis makronutrien: Karbohidrat, Protein, Lemak...',
      'Menyusun ulasan kesehatan & rekomendasi edukatif...',
    ];

    let current = 0;
    const interval = setInterval(() => {
      current = (current + 1) % steps.length;
      setLoadingStep(steps[current]);
    }, 1800);

    return () => clearInterval(interval);
  }, [isLoading]);

  // Handle sample food selection
  const handleSelectSample = (sample: SampleFoodItem) => {
    setSelectedImage(sample.imageUrl);
    setSelectedMimeType('image/jpeg');
    setFoodHint(sample.title);
    setErrorMessage(null);

    // Pre-populate result directly from verified high-quality sample data
    const sampleResult: NutritionAnalysisResult = {
      foodName: sample.title,
      servingSize: '1 Porsi Lengkap (~300g)',
      calories: sample.calories,
      carbohydrates: sample.carbs,
      protein: sample.protein,
      fat: sample.fat,
      fiber: sample.fiber,
      healthReview: sample.healthReview,
      nutritionistAdvice: sample.nutritionistAdvice,
      nutriScore: sample.nutriScore,
      schoolSuitability: sample.schoolSuitability,
      analyzedAt: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      imageUrl: sample.imageUrl,
    };

    setResult(sampleResult);

    // Add to history
    setHistory((prev) => {
      const filtered = prev.filter((item) => item.foodName !== sampleResult.foodName);
      return [sampleResult, ...filtered].slice(0, 8);
    });

    // Smooth scroll to result
    setTimeout(() => {
      const el = document.getElementById('hasil-analisis-gizi');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 150);
  };

  // Perform AI Nutrition Analysis
  const handleAnalyzeNutrition = async () => {
    if (!selectedImage) {
      setErrorMessage('Silakan pilih atau unggah foto makanan terlebih dahulu.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      // Send base64 payload to backend server
      const response = await fetch('/api/analyze-nutrition', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType: selectedMimeType,
          foodHint: foodHint.trim() || undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server error (${response.status})`);
      }

      const data: NutritionAnalysisResult = await response.json();
      const enrichedResult: NutritionAnalysisResult = {
        ...data,
        analyzedAt: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        imageUrl: selectedImage,
      };

      setResult(enrichedResult);

      // Add to history
      setHistory((prev) => {
        const filtered = prev.filter((item) => item.foodName !== enrichedResult.foodName);
        return [enrichedResult, ...filtered].slice(0, 8);
      });

      // Smooth scroll to results
      setTimeout(() => {
        const el = document.getElementById('hasil-analisis-gizi');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 200);
    } catch (err: any) {
      console.error('Failed to analyze nutrition:', err);
      setErrorMessage(
        err.message || 'Terjadi kendala saat menganalisis foto makanan. Mohon coba lagi.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedImage(null);
    setResult(null);
    setFoodHint('');
    setErrorMessage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {/* 1. Header Bagian Atas */}
      <Header
        studentName={studentName}
        setStudentName={setStudentName}
        studentClass={studentClass}
        setStudentClass={setStudentClass}
        showStudentInfoModal={showStudentModal}
        setShowStudentInfoModal={setShowStudentModal}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Project Context & Instructions Banner */}
        <div className="bg-linear-to-r from-blue-50/80 via-emerald-50/80 to-blue-50/80 border border-blue-200/70 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#3498db] text-white flex items-center justify-center shrink-0 shadow-xs">
              <BookCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900">
                Tugas Proyek Sains: Pembelajaran Gizi & Pola Hidup Sehat
              </h2>
              <p className="text-xs sm:text-sm text-slate-600">
                Gunakan alat ini untuk meneliti kandungan makanan sehari-hari, mendokumentasikan kalori, dan mempelajari saran ahli gizi.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowStudentModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-700 transition-colors self-start sm:self-center shrink-0 shadow-2xs"
          >
            Edit Data Lembar Tugas
          </button>
        </div>

        {/* Error Alert if any */}
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-300 text-rose-800 px-4 py-3 rounded-2xl flex items-center gap-3 text-sm animate-fade-in shadow-2xs">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <div className="flex-1">
              <p className="font-semibold">Pemberitahuan</p>
              <p className="text-xs sm:text-sm">{errorMessage}</p>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-xs underline text-rose-700 hover:text-rose-900"
            >
              Tutup
            </button>
          </div>
        )}

        {/* 2. Bagian Tengah: Area Mengunggah atau Memasukkan File Foto Makanan */}
        <ImageUploadArea
          selectedImage={selectedImage}
          setSelectedImage={setSelectedImage}
          selectedMimeType={selectedMimeType}
          setSelectedMimeType={setSelectedMimeType}
          foodHint={foodHint}
          setFoodHint={setFoodHint}
          onSelectSample={handleSelectSample}
          isLoading={isLoading}
        />

        {/* 3. Tombol Besar: "Analisis Nutrisi Makanan" */}
        <AnalyzeButton
          onClick={handleAnalyzeNutrition}
          isLoading={isLoading}
          disabled={!selectedImage}
          loadingStepText={loadingStep}
        />

        {/* 4. Bagian Hasil Analisis Gizi */}
        {result && (
          <NutritionResultCard
            result={result}
            onPrint={() => setShowStudentModal(true)}
            onReset={handleReset}
          />
        )}

        {/* Riwayat Analisis Siswa (Comparisons for Homework) */}
        {history.length > 1 && (
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm no-print">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm sm:text-base font-bold text-slate-800 flex items-center gap-2">
                <History className="w-4 h-4 text-[#3498db]" />
                Riwayat Analisis Makanan Sesi Ini
              </h3>
              <button
                onClick={() => setHistory([])}
                className="text-xs text-slate-600 hover:text-rose-600 font-medium"
              >
                Hapus Riwayat
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {history.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setResult(item);
                    if (item.imageUrl) setSelectedImage(item.imageUrl);
                    const el = document.getElementById('hasil-analisis-gizi');
                    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    result?.foodName === item.foodName
                      ? 'border-[#2ecc71] bg-emerald-50/40 ring-2 ring-[#2ecc71]/20'
                      : 'border-slate-200 hover:border-[#3498db] bg-slate-50/50 hover:bg-white'
                  }`}
                >
                  <p className="font-bold text-xs sm:text-sm text-slate-800 truncate">
                    {item.foodName}
                  </p>
                  <div className="flex items-center justify-between mt-1 text-xs">
                    <span className="font-black text-[#e74c3c]">{item.calories} kkal</span>
                    <span className="text-[11px] text-slate-600">
                      C:{item.carbohydrates}g | P:{item.protein}g | L:{item.fat}g
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Panduan Edukasi Gizi Pelajar */}
        <EducationalGuide />
      </main>

      {/* Footer */}
      <footer className="mt-12 bg-white border-t border-slate-200/80 py-8 text-center text-xs text-slate-500 no-print">
        <div className="max-w-5xl mx-auto px-4 flex flex-col items-center justify-center space-y-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full pb-4 border-b border-slate-100 text-slate-600">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71]" />
              <span className="font-semibold text-slate-700">NutriAI🍎</span>
              <span>—</span>
              <span>Inovasi Pembelajaran Digital Sekolah</span>
            </div>
            <p className="text-slate-500">
              Ditenagai Kecerdasan Buatan Google Gemini • Untuk Keperluan Edukasi & Tugas Siswa
            </p>
          </div>

          {/* Identitas Kelompok */}
          <div className="text-center text-xs text-slate-500 leading-relaxed whitespace-pre-line">
{`Dibuat oleh Kelompok 3
Anggota:
- Fazri Nursyam Mamang
- Asyifa mappa
- Nischa
- Renata Kesya
- Ilham
- Ahmad Rahmat
- Parlan
- Eby
-Aurel
Untuk tugas koding :3`}
          </div>
        </div>
      </footer>

      {/* Printable Student Assignment Modal */}
      <StudentReportModal
        isOpen={showStudentModal}
        onClose={() => setShowStudentModal(false)}
        result={result}
        studentName={studentName}
        setStudentName={setStudentName}
        studentClass={studentClass}
        setStudentClass={setStudentClass}
        studentNumber={studentNumber}
        setStudentNumber={setStudentNumber}
        subjectName={subjectName}
        setSubjectName={setSubjectName}
        teacherName={teacherName}
        setTeacherName={setTeacherName}
      />
    </div>
  );
}
