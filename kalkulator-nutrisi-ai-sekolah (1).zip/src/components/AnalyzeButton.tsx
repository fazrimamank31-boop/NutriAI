import React from 'react';
import { Sparkles, Loader2, Search } from 'lucide-react';

interface AnalyzeButtonProps {
  onClick: () => void;
  isLoading: boolean;
  disabled: boolean;
  loadingStepText?: string;
}

export const AnalyzeButton: React.FC<AnalyzeButtonProps> = ({
  onClick,
  isLoading,
  disabled,
  loadingStepText = 'AI sedang memindai kandungan gizi...',
}) => {
  return (
    <div className="my-6 text-center">
      <button
        type="button"
        onClick={onClick}
        disabled={disabled || isLoading}
        className={`w-full sm:w-auto min-w-[280px] sm:min-w-[340px] px-8 py-4 sm:py-4.5 rounded-2xl text-white font-extrabold text-base sm:text-lg tracking-wide shadow-lg transition-all transform flex items-center justify-center gap-3 mx-auto ${
          disabled
            ? 'bg-slate-300 cursor-not-allowed text-slate-500 shadow-none'
            : isLoading
            ? 'bg-linear-to-r from-[#2ecc71] via-[#3498db] to-[#2ecc71] cursor-wait animate-pulse shadow-[#2ecc71]/30'
            : 'bg-linear-to-r from-[#2ecc71] to-[#27ae60] hover:from-[#27ae60] hover:to-[#219653] active:scale-[0.98] shadow-[#2ecc71]/40 hover:shadow-xl hover:shadow-[#2ecc71]/30 hover:-translate-y-0.5'
        }`}
      >
        {isLoading ? (
          <>
            <Loader2 className="w-6 h-6 animate-spin text-white" />
            <div className="text-left">
              <span className="block leading-tight">Menganalisis Makanan...</span>
              <span className="block text-xs font-normal text-white/90">
                {loadingStepText}
              </span>
            </div>
          </>
        ) : (
          <>
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span>Analisis Nutrisi Makanan</span>
            <Search className="w-5 h-5 text-white/80 ml-1 hidden sm:inline-block" />
          </>
        )}
      </button>

      {disabled && !isLoading && (
        <p className="text-xs text-slate-600 mt-2">
          *Unggah atau pilih foto makanan di atas terlebih dahulu untuk memulai analisis.
        </p>
      )}
    </div>
  );
};
