import React, { useState } from 'react';
import { BookOpen, ChevronDown, ChevronUp, Utensils, ShieldCheck, Heart, Sparkles } from 'lucide-react';

export const EducationalGuide: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden transition-all no-print">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-5 sm:px-6 py-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#3498db]/15 text-[#3498db] flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-800 flex items-center gap-2">
              Panduan Edukasi: "Isi Piringku" & Tips Gizi Sehat Sekolah
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                Materi Belajar
              </span>
            </h3>
            <p className="text-xs text-slate-500">
              Kementerian Kesehatan RI & Konsep 4 Sehat 5 Sempurna Modern
            </p>
          </div>
        </div>

        <div className="text-slate-400">
          {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </div>
      </button>

      {isOpen && (
        <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-slate-100 space-y-5 text-slate-700 text-xs sm:text-sm">
          {/* Section 1: Porsi Isi Piringku */}
          <div>
            <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
              <Utensils className="w-4 h-4 text-[#2ecc71]" />
              Pedoman Porsi Makan Sehat "Isi Piringku":
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                <p className="font-bold text-amber-900 text-sm">2/3 Piring Kiri</p>
                <p className="font-extrabold text-amber-800 mt-0.5">Makanan Pokok</p>
                <p className="text-[11px] text-amber-700 mt-1">Nasi, kentang, jagung, roti gandum, atau ubi jalar.</p>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <p className="font-bold text-emerald-900 text-sm">2/3 Piring Kanan</p>
                <p className="font-extrabold text-emerald-800 mt-0.5">Sayur-Mayur</p>
                <p className="text-[11px] text-emerald-700 mt-1">Bayam, kangkung, wortel, buncis, brokoli, labu siam.</p>
              </div>

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
                <p className="font-bold text-blue-900 text-sm">1/3 Piring Kiri</p>
                <p className="font-extrabold text-blue-800 mt-0.5">Lauk Hewani & Nabati</p>
                <p className="text-[11px] text-blue-700 mt-1">Ikan, telur, tempe, tahu, daging ayam tanpa kulit.</p>
              </div>

              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200">
                <p className="font-bold text-rose-900 text-sm">1/3 Piring Kanan</p>
                <p className="font-extrabold text-rose-800 mt-0.5">Buah-buahan</p>
                <p className="text-[11px] text-rose-700 mt-1">Pisang, pepaya, jeruk, apel, semangka segar.</p>
              </div>
            </div>
          </div>

          {/* Section 2: Tips Kantin Sehat */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3498db]" />
              Tips Cerdas Memilih Jajanan di Kantin Sekolah:
            </h4>
            <ul className="list-disc list-inside space-y-1.5 text-slate-600 text-xs sm:text-sm pl-1">
              <li>
                <strong className="text-slate-800">Perhatikan Minyak:</strong> Batasi gorengan yang warnanya sudah cokelat gelap atau berminyak pekat.
              </li>
              <li>
                <strong className="text-slate-800">Cek Kebersihan:</strong> Pastikan wadah makanan tertutup rapat dari lalat atau debu halaman sekolah.
              </li>
              <li>
                <strong className="text-slate-800">Kurangi Minuman Manis:</strong> Hindari minuman kemasan dengan pemanis buatan tinggi; prioritaskan air mineral 1.5 - 2 liter per hari.
              </li>
              <li>
                <strong className="text-slate-800">Jangan Lewatkan Sarapan:</strong> Sarapan bergizi seimbang meningkatkan nilai akademis dan mencegah pusing/lemas saat upacara atau olahraga.
              </li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
