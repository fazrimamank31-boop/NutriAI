import React from 'react';
import { Sparkles, GraduationCap, Apple, FileText } from 'lucide-react';

interface HeaderProps {
  studentName: string;
  setStudentName: (val: string) => void;
  studentClass: string;
  setStudentClass: (val: string) => void;
  showStudentInfoModal: boolean;
  setShowStudentInfoModal: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  studentName,
  studentClass,
  setShowStudentInfoModal,
}) => {
  return (
    <header className="relative overflow-hidden bg-white border-b border-slate-200/80 shadow-xs">
      {/* Decorative top colored bar */}
      <div className="h-1.5 w-full bg-linear-to-r from-[#2ecc71] via-[#3498db] to-[#2ecc71]" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Logo & Titles */}
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-linear-to-br from-[#2ecc71] to-[#27ae60] flex items-center justify-center text-white shadow-md shadow-[#2ecc71]/25 shrink-0 transform -rotate-1">
              <Apple className="w-6 h-6 sm:w-7 sm:h-7" />
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-50 text-[#3498db] text-xs font-semibold uppercase tracking-wider mb-1 border border-blue-100">
                <GraduationCap className="w-3.5 h-3.5 text-[#3498db]" />
                <span>Media Tugas Proyek Sains & Kesehatan Siswa</span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                NutriAI🍎
                <Sparkles className="w-5 h-5 text-[#2ecc71] hidden sm:inline-block animate-pulse" />
              </h1>

              <p className="text-slate-600 text-sm sm:text-base mt-0.5">
                Pindai foto makanan bekal atau jajanan kantin untuk menghitung kalori, makronutrisi, serta ulasan edukatif gizi seimbang.
              </p>
            </div>
          </div>

          {/* Student Profile Badge for Homework */}
          <div className="flex items-center gap-2.5 self-start md:self-center shrink-0">
            <button
              onClick={() => setShowStudentInfoModal(true)}
              className="group flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs sm:text-sm font-medium text-slate-700 transition-all shadow-2xs hover:border-[#3498db]/40"
              title="Klik untuk mengisi identitas tugas siswa"
            >
              <div className="w-7 h-7 rounded-lg bg-[#3498db]/15 text-[#3498db] flex items-center justify-center font-bold text-xs">
                {studentName ? studentName.charAt(0).toUpperCase() : 'S'}
              </div>
              <div className="text-left">
                <p className="text-[11px] text-slate-600 font-normal">Identitas Siswa</p>
                <p className="font-semibold text-slate-800 truncate max-w-[130px]">
                  {studentName || 'Klik Isi Nama Siswa'}
                </p>
              </div>
              <FileText className="w-4 h-4 text-slate-600 group-hover:text-[#3498db] transition-colors ml-1" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
