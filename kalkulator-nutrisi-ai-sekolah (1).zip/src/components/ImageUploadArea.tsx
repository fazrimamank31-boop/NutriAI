import React, { useRef } from 'react';
import { UploadCloud, Image as ImageIcon, Camera, Trash2, CheckCircle2, Sparkles } from 'lucide-react';
import { SAMPLE_FOODS } from '../data/sampleFoods';
import { SampleFoodItem } from '../types';

interface ImageUploadAreaProps {
  selectedImage: string | null;
  setSelectedImage: (val: string | null) => void;
  selectedMimeType: string;
  setSelectedMimeType: (val: string) => void;
  foodHint: string;
  setFoodHint: (val: string) => void;
  onSelectSample: (sample: SampleFoodItem) => void;
  isLoading: boolean;
}

export const ImageUploadArea: React.FC<ImageUploadAreaProps> = ({
  selectedImage,
  setSelectedImage,
  selectedMimeType,
  setSelectedMimeType,
  foodHint,
  setFoodHint,
  onSelectSample,
  isLoading,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = React.useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Mohon pilih file gambar (JPG, PNG, WEBP).');
      return;
    }

    const mime = file.type || 'image/jpeg';
    setSelectedMimeType(mime);

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleClearImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-6 transition-all">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-[#2ecc71]/15 text-[#2ecc71] flex items-center justify-center text-xs font-black">
              1
            </span>
            Masukkan Foto Makanan
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Unggah foto bekal, sarapan, atau makanan kantin yang ingin dianalisis gizinya.
          </p>
        </div>

        {selectedImage && (
          <button
            onClick={handleClearImage}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Ganti Foto</span>
          </button>
        )}
      </div>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
        id="food-photo-upload"
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
        id="food-camera-capture"
      />

      {/* Drop / Preview Area */}
      {!selectedImage ? (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-xl p-8 sm:p-10 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-[#2ecc71] bg-emerald-50/50 scale-[0.99]'
              : 'border-slate-300 hover:border-[#3498db] bg-slate-50/60 hover:bg-blue-50/20'
          }`}
        >
          <div className="mx-auto w-16 h-16 rounded-2xl bg-white shadow-xs border border-slate-200 flex items-center justify-center text-[#3498db] mb-4 group-hover:scale-105 transition-transform">
            <UploadCloud className="w-8 h-8 text-[#3498db]" />
          </div>

          <h3 className="text-base font-semibold text-slate-800 mb-1">
            Klik untuk Pilih File Foto Makanan
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto mb-4">
            Bisa seret & lepas file foto ke sini. Format yang didukung: JPG, PNG, WEBP (Maks. 15MB).
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#3498db] hover:bg-[#2980b9] text-white text-xs sm:text-sm font-semibold shadow-xs transition-colors"
            >
              <ImageIcon className="w-4 h-4" />
              Pilih dari Galeri / File
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                cameraInputRef.current?.click();
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs sm:text-sm font-semibold shadow-2xs transition-colors"
            >
              <Camera className="w-4 h-4 text-[#2ecc71]" />
              Ambil Foto Langsung
            </button>
          </div>
        </div>
      ) : (
        /* Image Preview Box */
        <div className="space-y-4">
          <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-900 group max-h-80 flex items-center justify-center">
            <img
              src={selectedImage}
              alt="Foto makanan yang dipilih"
              className="w-full max-h-80 object-contain mx-auto"
            />
            <div className="absolute top-3 right-3 flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-xs text-white text-xs font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#2ecc71]" />
                Foto Siap Dianalisis
              </span>
            </div>
          </div>

          {/* Optional Food Hint Input */}
          <div className="bg-slate-50 p-3 sm:p-3.5 rounded-xl border border-slate-200/80">
            <label htmlFor="food-hint-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Catatan Tambahan untuk AI (Opsional)
            </label>
            <input
              id="food-hint-input"
              type="text"
              value={foodHint}
              onChange={(e) => setFoodHint(e.target.value)}
              placeholder="Contoh: 1 porsi bekal nasi telur dengan sambal sedikit, atau porsi mangkok bakso sedang"
              className="w-full text-xs sm:text-sm px-3 py-2 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db] focus:border-transparent text-slate-800"
            />
          </div>
        </div>
      )}

      {/* Quick Preset Samples for Easy Testing */}
      <div className="mt-5 pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#2ecc71]" />
            Atau Coba Contoh Makanan Sekolah Siap Pakai:
          </span>
          <span className="text-[11px] text-slate-600 hidden sm:inline">Klik salah satu untuk uji cepat</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {SAMPLE_FOODS.map((sample) => (
            <button
              key={sample.id}
              type="button"
              disabled={isLoading}
              onClick={() => onSelectSample(sample)}
              className="flex flex-col text-left p-2 rounded-xl border border-slate-200 hover:border-[#2ecc71] bg-white hover:bg-emerald-50/30 transition-all group overflow-hidden shadow-2xs"
            >
              <div className="h-20 w-full rounded-lg overflow-hidden mb-1.5 bg-slate-100 relative">
                <img
                  src={sample.imageUrl}
                  alt={sample.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded-md bg-slate-900/75 text-[10px] text-white font-medium">
                  {sample.calories} kkal
                </span>
              </div>
              <span className="text-xs font-semibold text-slate-800 group-hover:text-[#2ecc71] line-clamp-1 transition-colors">
                {sample.title}
              </span>
              <span className="text-[11px] text-slate-600 line-clamp-1">
                {sample.category}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
