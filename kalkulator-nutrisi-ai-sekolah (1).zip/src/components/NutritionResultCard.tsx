import React from 'react';
import {
  Flame,
  Wheat,
  Dna,
  Droplet,
  HeartPulse,
  Lightbulb,
  Printer,
  Share2,
  Check,
  Scale,
  Award,
  Sparkles,
  Info,
} from 'lucide-react';
import { NutritionAnalysisResult } from '../types';

interface NutritionResultCardProps {
  result: NutritionAnalysisResult;
  onPrint: () => void;
  onReset: () => void;
}

export const NutritionResultCard: React.FC<NutritionResultCardProps> = ({
  result,
  onPrint,
  onReset,
}) => {
  const [copied, setCopied] = React.useState(false);

  // Student Daily Energy Needs Benchmark (Angka Kecukupan Gizi / AKG Remaja Sekolah ~ 2100 kkal)
  const DAILY_CALORIE_BENCHMARK = 2100;
  const caloriePercentOfDaily = Math.round((result.calories / DAILY_CALORIE_BENCHMARK) * 100);

  // Macro calorie contributions (Carbs: 4 kcal/g, Protein: 4 kcal/g, Fat: 9 kcal/g)
  const carbsKcal = Math.round(result.carbohydrates * 4);
  const proteinKcal = Math.round(result.protein * 4);
  const fatKcal = Math.round(result.fat * 9);
  const totalMacroKcal = carbsKcal + proteinKcal + fatKcal || 1;

  const carbsPct = Math.round((carbsKcal / totalMacroKcal) * 100);
  const proteinPct = Math.round((proteinKcal / totalMacroKcal) * 100);
  const fatPct = Math.max(0, 100 - carbsPct - proteinPct);

  const handleCopySummary = () => {
    const text = `📋 LAPORAN TUGAS GIZI SEKOLAH
Nama Makanan: ${result.foodName}
Porsi: ${result.servingSize || '1 porsi'}
Total Kalori: ${result.calories} kkal
• Karbohidrat: ${result.carbohydrates} g (${carbsPct}%)
• Protein: ${result.protein} g (${proteinPct}%)
• Lemak: ${result.fat} g (${fatPct}%)
${result.fiber ? `• Serat: ${result.fiber} g` : ''}

Ulasan Kesehatan:
${result.healthReview}

Saran Edukatif Ahli Gizi:
${result.nutritionistAdvice}
— Dibuat dengan NutriAI🍎`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div id="hasil-analisis-gizi" className="space-y-6 pt-2 scroll-mt-6">
      {/* Main Analysis Card */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-lg shadow-slate-200/50 overflow-hidden print-card">
        {/* Card Header with Food Name & Badges */}
        <div className="bg-linear-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-5 sm:p-7 relative overflow-hidden">
          {/* Subtle background decoration */}
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-[#2ecc71]/15 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute right-32 -top-8 w-32 h-32 bg-[#3498db]/15 rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#2ecc71]/20 border border-[#2ecc71]/30 text-[#2ecc71] text-xs font-bold tracking-wide">
                  <Sparkles className="w-3.5 h-3.5" />
                  Hasil Deteksi AI
                </span>

                {result.nutriScore && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#3498db]/20 border border-[#3498db]/30 text-sky-300 text-xs font-semibold">
                    <Award className="w-3.5 h-3.5" />
                    Nutri-Score: {result.nutriScore}
                  </span>
                )}
              </div>

              {/* 1. Nama makanan yang terdeteksi */}
              <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white capitalize">
                {result.foodName}
              </h3>

              {result.servingSize && (
                <p className="text-xs sm:text-sm text-slate-300 mt-1 flex items-center gap-1.5 font-medium">
                  <Scale className="w-4 h-4 text-slate-400" />
                  Estimasi Takaran: <span className="text-white font-semibold">{result.servingSize}</span>
                </p>
              )}
            </div>

            {/* Quick Actions (Copy & Print) */}
            <div className="flex items-center gap-2 no-print self-start sm:self-center">
              <button
                onClick={handleCopySummary}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-xs transition-colors"
                title="Salin teks rangkuman nutrisi"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#2ecc71]" />
                    <span className="text-[#2ecc71]">Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Salin Hasil</span>
                  </>
                )}
              </button>

              <button
                onClick={onPrint}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#3498db] hover:bg-[#2980b9] text-white text-xs font-semibold transition-colors shadow-xs"
                title="Cetak lembar laporan tugas siswa"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Laporan</span>
              </button>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 space-y-7">
          {/* 2. Estimasi total kalori (kkal) dengan teks agak besar berwarna merah */}
          <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-[#e74c3c]/15 text-[#e74c3c] flex items-center justify-center shrink-0">
                <Flame className="w-8 h-8 sm:w-9 sm:h-9 fill-[#e74c3c]/20" />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-rose-700 block mb-0.5">
                  Estimasi Total Kalori
                </span>
                {/* Large Red Text for Calories */}
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl sm:text-5xl font-black text-[#e74c3c] tracking-tight">
                    {result.calories.toLocaleString('id-ID')}
                  </span>
                  <span className="text-xl sm:text-2xl font-bold text-[#e74c3c]">
                    kkal
                  </span>
                </div>
              </div>
            </div>

            {/* School AKG Context Pill */}
            <div className="bg-white/90 border border-rose-200 rounded-xl p-3 sm:p-3.5 text-xs text-slate-700 max-w-xs">
              <div className="flex items-center justify-between font-semibold mb-1">
                <span className="text-slate-800">Kebutuhan Harian Siswa:</span>
                <span className="text-[#e74c3c] font-black">{caloriePercentOfDaily}% AKG</span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#e74c3c] h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(caloriePercentOfDaily, 100)}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Dari standar rata-rata energi harian pelajar ~{DAILY_CALORIE_BENCHMARK} kkal.
              </p>
            </div>
          </div>

          {/* 3. Tiga kotak bersebelahan (grid) untuk rincian gram Karbohidrat, Protein, dan Lemak */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-extrabold uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#3498db]" />
                Rincian Makronutrisi Makanan
              </h4>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                Standar Kebutuhan Tubuh Siswa
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
              {/* Kotak 1: Karbohidrat */}
              <div className="bg-amber-50/60 border border-amber-200/90 rounded-2xl p-4 sm:p-5 relative overflow-hidden transition-all hover:shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-800 uppercase tracking-wider">
                    Karbohidrat
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Wheat className="w-4 h-4" />
                  </div>
                </div>

                <div className="flex items-baseline gap-1.5 mb-2">
                  <span className="text-3xl font-black text-amber-900 tracking-tight">
                    {result.carbohydrates}
                  </span>
                  <span className="text-base font-bold text-amber-700">gram</span>
                </div>

                {/* Energy contribution */}
                <div className="text-[11px] font-medium text-amber-800/80 mb-2.5 flex items-center justify-between">
                  <span>Kontribusi Energi:</span>
                  <span className="font-bold">{carbsKcal} kkal ({carbsPct}%)</span>
                </div>

                <div className="w-full bg-amber-200/80 h-1.5 rounded-full overflow-hidden mb-2">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${carbsPct}%` }}
                  />
                </div>

                <p className="text-[11px] text-amber-900/70 leading-relaxed">
                  Bahan bakar utama untuk daya ingat, fokus, dan konsentrasi belajar di sekolah.
                </p>
              </div>

              {/* Kotak 2: Protein */}
              <div className="bg-blue-50/60 border border-blue-200/90 rounded-2xl p-4 sm:p-5 relative overflow-hidden transition-all hover:shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#3498db] uppercase tracking-wider">
                    Protein
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-[#3498db] flex items-center justify-center">
                    <Dna className="w-4 h-4" />
                  </div>
                </div>

                <div className="flex items-baseline gap-1.5 mb-2">
                  <span className="text-3xl font-black text-slate-800 tracking-tight">
                    {result.protein}
                  </span>
                  <span className="text-base font-bold text-blue-600">gram</span>
                </div>

                {/* Energy contribution */}
                <div className="text-[11px] font-medium text-slate-600 mb-2.5 flex items-center justify-between">
                  <span>Kontribusi Energi:</span>
                  <span className="font-bold text-slate-800">{proteinKcal} kkal ({proteinPct}%)</span>
                </div>

                <div className="w-full bg-blue-200/80 h-1.5 rounded-full overflow-hidden mb-2">
                  <div
                    className="bg-[#3498db] h-full rounded-full transition-all duration-500"
                    style={{ width: `${proteinPct}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Mendukung pertumbuhan tinggi badan, pembentukan otot, dan regenerasi jaringan.
                </p>
              </div>

              {/* Kotak 3: Lemak */}
              <div className="bg-orange-50/60 border border-orange-200/90 rounded-2xl p-4 sm:p-5 relative overflow-hidden transition-all hover:shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-orange-800 uppercase tracking-wider">
                    Lemak
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center">
                    <Droplet className="w-4 h-4" />
                  </div>
                </div>

                <div className="flex items-baseline gap-1.5 mb-2">
                  <span className="text-3xl font-black text-orange-950 tracking-tight">
                    {result.fat}
                  </span>
                  <span className="text-base font-bold text-orange-700">gram</span>
                </div>

                {/* Energy contribution */}
                <div className="text-[11px] font-medium text-orange-800/80 mb-2.5 flex items-center justify-between">
                  <span>Kontribusi Energi:</span>
                  <span className="font-bold">{fatKcal} kkal ({fatPct}%)</span>
                </div>

                <div className="w-full bg-orange-200/80 h-1.5 rounded-full overflow-hidden mb-2">
                  <div
                    className="bg-orange-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${fatPct}%` }}
                  />
                </div>

                <p className="text-[11px] text-orange-900/70 leading-relaxed">
                  Cadangan tenaga serta pelindung organ dan pelarut vitamin penting (A, D, E, K).
                </p>
              </div>
            </div>

            {/* Optional Fiber / Dietary Fiber Banner */}
            {typeof result.fiber === 'number' && (
              <div className="mt-3 py-2 px-3.5 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs text-slate-700">
                <span className="flex items-center gap-1.5 font-medium">
                  <Info className="w-3.5 h-3.5 text-[#2ecc71]" />
                  Kandungan Serat Pangan Alami:
                </span>
                <span className="font-bold text-slate-800">
                  {result.fiber} gram (Sangat baik untuk pencernaan sehat)
                </span>
              </div>
            )}
          </div>

          {/* 4. Paragraf ulasan singkat mengenai kesehatan makanan tersebut */}
          <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-5 sm:p-6">
            <h4 className="text-sm font-extrabold uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-rose-500" />
              Ulasan Kesehatan Makanan
            </h4>
            <p className="text-slate-700 text-sm sm:text-base leading-relaxed whitespace-pre-line">
              {result.healthReview}
            </p>
          </div>

          {/* 5. Kotak khusus dengan latar belakang hijau muda untuk "Saran Edukatif dari Ahli Gizi" */}
          <div className="bg-[#e8f8f0] border-2 border-[#2ecc71]/60 rounded-2xl p-5 sm:p-6 relative shadow-xs">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-[#2ecc71] text-white flex items-center justify-center shrink-0 shadow-sm shadow-[#2ecc71]/30">
                <Lightbulb className="w-5 h-5" />
              </div>

              <div className="space-y-1.5 w-full">
                <div className="flex items-center justify-between">
                  <h4 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5">
                    Saran Edukatif dari Ahli Gizi
                  </h4>
                  <span className="px-2 py-0.5 rounded-full bg-[#2ecc71]/20 text-emerald-800 text-[11px] font-bold">
                    Khusus Pelajar
                  </span>
                </div>

                <p className="text-slate-800 text-sm sm:text-base leading-relaxed font-normal whitespace-pre-line">
                  {result.nutritionistAdvice}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 px-5 sm:px-7 py-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
          <p className="text-xs text-slate-500">
            *Hasil estimasi AI berbasis rata-rata kandungan nutrisi untuk referensi pembelajaran sekolah.
          </p>

          <div className="flex items-center gap-2">
            <button
              onClick={onReset}
              className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs sm:text-sm font-semibold transition-colors"
            >
              Pindai Makanan Lain
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
