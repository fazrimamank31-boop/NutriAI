import React from 'react';
import { X, Printer, GraduationCap, CheckCircle2 } from 'lucide-react';
import { NutritionAnalysisResult } from '../types';

interface StudentReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: NutritionAnalysisResult | null;
  studentName: string;
  setStudentName: (val: string) => void;
  studentClass: string;
  setStudentClass: (val: string) => void;
  studentNumber: string;
  setStudentNumber: (val: string) => void;
  subjectName: string;
  setSubjectName: (val: string) => void;
  teacherName: string;
  setTeacherName: (val: string) => void;
}

export const StudentReportModal: React.FC<StudentReportModalProps> = ({
  isOpen,
  onClose,
  result,
  studentName,
  setStudentName,
  studentClass,
  setStudentClass,
  studentNumber,
  setStudentNumber,
  subjectName,
  setSubjectName,
  teacherName,
  setTeacherName,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2.5">
            <GraduationCap className="w-5 h-5 text-[#2ecc71]" />
            <h3 className="font-bold text-base sm:text-lg">
              Lembar Tugas Proyek Siswa: Analisis Gizi
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body / Printable Worksheet */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Identity Form (Hidden in print once filled or rendered cleanly) */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#3498db]" />
              Identitas Siswa & Tugas Sekolah
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Nama Siswa:
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Contoh: Muhammad Bintang Pratama"
                  className="w-full text-xs sm:text-sm px-3 py-1.5 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Kelas / No. Absen:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={studentClass}
                    onChange={(e) => setStudentClass(e.target.value)}
                    placeholder="Kelas (contoh: VIII-B / X IPA 2)"
                    className="w-2/3 text-xs sm:text-sm px-3 py-1.5 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db]"
                  />
                  <input
                    type="text"
                    value={studentNumber}
                    onChange={(e) => setStudentNumber(e.target.value)}
                    placeholder="No. Absen"
                    className="w-1/3 text-xs sm:text-sm px-2 py-1.5 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Mata Pelajaran:
                </label>
                <input
                  type="text"
                  value={subjectName}
                  onChange={(e) => setSubjectName(e.target.value)}
                  placeholder="IPA / Biologi / Prakarya / Penjas"
                  className="w-full text-xs sm:text-sm px-3 py-1.5 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Guru Pembimbing (Opsional):
                </label>
                <input
                  type="text"
                  value={teacherName}
                  onChange={(e) => setTeacherName(e.target.value)}
                  placeholder="Nama Bapak/Ibu Guru"
                  className="w-full text-xs sm:text-sm px-3 py-1.5 rounded-lg bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#3498db]"
                />
              </div>
            </div>
          </div>

          {/* Report Preview if Result exists */}
          {result ? (
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4">
              <div className="border-b pb-3 flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-lg text-slate-900">
                    {result.foodName}
                  </h4>
                  <p className="text-xs text-slate-500">
                    Ukuran Porsi: {result.servingSize || '1 Porsi Lengkap'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-[#e74c3c]">
                    {result.calories} kkal
                  </span>
                  <p className="text-[11px] text-slate-500">Total Energi Makanan</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center py-2 bg-slate-50 rounded-xl">
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">Karbohidrat</p>
                  <p className="font-extrabold text-slate-800 text-sm">{result.carbohydrates} g</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">Protein</p>
                  <p className="font-extrabold text-[#3498db] text-sm">{result.protein} g</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">Lemak</p>
                  <p className="font-extrabold text-orange-600 text-sm">{result.fat} g</p>
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-700 uppercase mb-1">
                  Ulasan Gizi & Kesehatan:
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {result.healthReview}
                </p>
              </div>

              <div className="p-3 bg-[#e8f8f0] border border-[#2ecc71]/40 rounded-xl">
                <p className="text-xs font-bold text-emerald-900 uppercase mb-1">
                  Saran Edukatif Ahli Gizi:
                </p>
                <p className="text-xs text-emerald-950 leading-relaxed">
                  {result.nutritionistAdvice}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 text-center py-4">
              Belum ada makanan yang dianalisis. Silakan lakukan pemindaian foto makanan di halaman utama terlebih dahulu.
            </p>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between no-print">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs sm:text-sm font-semibold hover:bg-slate-100 transition-colors"
          >
            Tutup
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-linear-to-r from-[#2ecc71] to-[#27ae60] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#2ecc71]/25 hover:shadow-lg transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak / Unduh PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
