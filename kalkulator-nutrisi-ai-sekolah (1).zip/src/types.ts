export interface NutritionAnalysisResult {
  foodName: string;
  servingSize: string;
  calories: number;
  carbohydrates: number;
  protein: number;
  fat: number;
  fiber?: number;
  healthReview: string;
  nutritionistAdvice: string;
  nutriScore?: string;
  schoolSuitability?: string;
  macroPercentages?: {
    carbsPercent: number;
    proteinPercent: number;
    fatPercent: number;
  };
  analyzedAt?: string;
  imageUrl?: string;
  isDemoFallback?: boolean;
}

export interface SampleFoodItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  description: string;
  calories: number;
  carbs: number;
  protein: number;
  fat: number;
  fiber: number;
  healthReview: string;
  nutritionistAdvice: string;
  nutriScore: string;
  schoolSuitability: string;
}
